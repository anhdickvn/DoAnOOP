package OOP;

public interface IGiamGia {
	public double tinhGiamGia();
}
